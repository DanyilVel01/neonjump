# Neon Leap

Оригинальный аркадный платформер для Godot 4. Откройте `project.godot` в Godot и запустите проект клавишей F5.

В меню выберите уровень сложности и нажмите «Начать игру». Уровни отличаются скоростью; рекорд сохраняется отдельно для каждого.

- Пробел, левая кнопка мыши или касание — прыжок.
- В участке с самолётиком удерживайте кнопку, чтобы лететь вверх, и отпускайте, чтобы снижаться.
- Прыгайте на движущиеся платформы: под ними находятся шипы.
- Escape — пауза / продолжение, R — начать заново, M — меню после паузы или столкновения.
- После столкновения пробел или щелчок запускает попытку заново.

Результаты хранятся локально в `user://neon_progress.save`.

## Physics and validation

Movement settings are centralized in `scripts/physics_config.gd`; physics runs at 120 fixed ticks per second. The player is 36 units wide. Gravity is 4000 units/s² and jump impulse is 900 units/s. Ideal constant-gravity calculations give 101.25 units of height, 0.225 s to apex, and 0.45 s in the air for a same-height landing. At base speed 480 units/s the ideal jump distance is:

| Portal mode | Multiplier | Speed | Ideal distance |
| --- | ---: | ---: | ---: |
| Slow | 0.75 | 360 | 162 |
| Normal | 1.00 | 480 | 216 |
| Fast | 1.25 | 600 | 270 |
| Very Fast | 1.50 | 720 | 324 |
| Extreme | 2.00 | 960 | 432 |

The discrete physics simulation differs slightly from these formulas. Difficulty starts at 480, 560 or 640 units/s; labelled speed portals near the end set the exact speeds in the table. Jump buffering, coyote time, and holding jump to jump again are enabled. Portals reset on restart.

Run `godot --headless --path . --script res://tests/physics_test.gd` to test speed modes, jump height/range, spike impacts, one portal crossing, restart, and basic level geometry. `scripts/level_validator.gd` checks only a subset of geometry and portal data; passing it does not establish that a whole level is beatable. In particular, the complete 30-obstacle set, gravity/reverse portals, timing hazards, and full recorded playthroughs are not implemented or verified yet.

The validator also estimates whether ascending platform jumps are reachable at each difficulty's initial speed and checks that paired ship obstacles leave a centre passage. Its negative tests inject an excessive platform rise and a blocked passage. Portal tests cross all five speed portals in sequence. These are geometry and component tests, not full level playthroughs.
