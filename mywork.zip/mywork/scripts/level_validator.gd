extends RefCounted
const Config = preload("res://scripts/physics_config.gd")
## Conservative geometry checks; timing and complete playthroughs require simulation.
static func analyze(game: Node) -> Array[String]:
    var warnings: Array[String] = []
    var minimum_gap: float = Config.PLAYER_SIZE + 8.0
    for i in range(1, game.steps.size()):
        var a: Vector2 = game.steps[i - 1]
        var b: Vector2 = game.steps[i]
        var dx: float = b.x - a.x
        var rise: float = b.y - a.y
        if dx < 600.0 and rise > 0.0:
            if rise >= Config.height(): warnings.append("Unreachable rise at x=%.0f" % b.x)
            if dx - 124.0 < minimum_gap: warnings.append("Narrow platform gap at x=%.0f" % b.x)
            var discriminant: float = Config.JUMP_IMPULSE * Config.JUMP_IMPULSE - 2.0 * Config.GRAVITY * rise
            if discriminant >= 0.0:
                var landing_time: float = (Config.JUMP_IMPULSE + sqrt(discriminant)) / Config.GRAVITY
                var travel: float = game.speeds[game.difficulty] * landing_time
                # Character centre may start/end anywhere over a platform.
                if absf(dx - travel) > 124.0 + Config.PLAYER_SIZE:
                    warnings.append("Platform jump out of range at x=%.0f" % b.x)
    for i in range(1, game.speed_portals.size()):
        if game.speed_portals[i].x <= game.speed_portals[i - 1].x:
            warnings.append("Speed portals are out of order")
    for portal in game.speed_portals:
        if int(portal.y) < 0 or int(portal.y) >= Config.SPEED_MULTIPLIERS.size():
            warnings.append("Invalid speed portal at x=%.0f" % portal.x)
    for i in range(game.flight_obstacles.size()):
        for j in range(i + 1, game.flight_obstacles.size()):
            var a: Vector2 = game.flight_obstacles[i]
            var b: Vector2 = game.flight_obstacles[j]
            if is_equal_approx(a.x, b.x) and absf(a.y - b.y) <= 210.0:
                warnings.append("Blocked ship passage at x=%.0f" % a.x)
    if game.flight_obstacles.is_empty(): warnings.append("No ship obstacles found")
    return warnings

