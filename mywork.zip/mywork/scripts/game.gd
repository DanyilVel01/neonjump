extends Node2D

const PhysicsConfig = preload("res://scripts/physics_config.gd")

const GROUND: float = 570.0
const FINISH: float = 38000.0
const SIZE: float = PhysicsConfig.PLAYER_SIZE
const GRAVITY: float = PhysicsConfig.GRAVITY
const JUMP: float = -PhysicsConfig.JUMP_IMPULSE
const FLIGHT_START: float = 16500.0
const FLIGHT_END: float = 20400.0
var spikes: Array[float] = []
var steps: Array[Vector2] = []
var flight_obstacles: Array[Vector2] = []
var speeds: Array[float] = [480.0, 560.0, 640.0]
var speed_mode: int = 1
var speed_portals: Array[Vector2] = []
var triggered_portals: Dictionary = {}
var names: Array[String] = ["BEGINNER", "PILOT", "EXPERT"]
var difficulty: int = 0
var speed: float = 480.0
var state: String = "menu"
var player: CharacterBody2D
var camera: Camera2D
var blocks: Array[StaticBody2D] = []
var timed_hazards: Array[Area2D] = []
const HazardScene = preload("res://scenes/obstacles/timed_hazard.tscn")
var jump_buffer: float = 0.0
var coyote_time: float = 0.0
var time: float = 0.0
var jump_requested: bool = false
var held: bool = false
var flying: bool = false
var angle: float = 0.0
var best: Array[int] = [0, 0, 0]
var menu: Control
var overlay: Label
var hud: Label
var bar: ProgressBar
var select: OptionButton

func _ready() -> void:
	_load_best()
	_create_world()
	_create_ui()
	_show_menu()

func _create_world() -> void:
	var ground := StaticBody2D.new()
	ground.position = Vector2(FINISH / 2.0, GROUND + 60.0)
	var ground_shape := CollisionShape2D.new()
	var ground_rect := RectangleShape2D.new()
	ground_rect.size = Vector2(FINISH + 2000.0, 120.0)
	ground_shape.shape = ground_rect
	ground.add_child(ground_shape)
	add_child(ground)
	for step in steps:
		var block := StaticBody2D.new()
		block.position = Vector2(step.x, GROUND - step.y + 15.0)
		var shape := CollisionShape2D.new()
		var rect := RectangleShape2D.new()
		rect.size = Vector2(124, 30)
		shape.shape = rect
		block.add_child(shape)
		add_child(block)
		blocks.append(block)
	player = CharacterBody2D.new()
	player.position = Vector2(180, GROUND - SIZE / 2)
	var shape := CollisionShape2D.new()
	var rect := RectangleShape2D.new()
	rect.size = Vector2(SIZE, SIZE)
	shape.shape = rect
	player.add_child(shape)
	add_child(player)
	camera = Camera2D.new()
	camera.position = Vector2(380, -190)
	camera.position_smoothing_enabled = true
	camera.position_smoothing_speed = 8.0
	player.add_child(camera)
	camera.make_current()

func _create_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	hud = Label.new()
	hud.position = Vector2(36, 24)
	hud.add_theme_font_size_override("font_size", 20)
	layer.add_child(hud)
	bar = ProgressBar.new()
	bar.position = Vector2(350, 30)
	bar.size = Vector2(580, 16)
	bar.show_percentage = false
	layer.add_child(bar)
	overlay = Label.new()
	overlay.position = Vector2(0, 130)
	overlay.size = Vector2(1280, 350)
	overlay.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	overlay.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	overlay.add_theme_font_size_override("font_size", 27)
	layer.add_child(overlay)
	menu = Control.new()
	menu.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	layer.add_child(menu)
	var shade := ColorRect.new()
	shade.color = Color(0.025, 0.04, 0.10, 0.88)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	menu.add_child(shade)
	var box := VBoxContainer.new()
	box.position = Vector2(390, 120)
	box.size = Vector2(500, 500)
	box.add_theme_constant_override("separation", 18)
	menu.add_child(box)
	var title := Label.new()
	title.text = "NEON LEAP"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 64)
	title.add_theme_color_override("font_color", Color("66f5df"))
	box.add_child(title)
	var subtitle := Label.new()
	subtitle.text = "SELECT DIFFICULTY"
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	subtitle.add_theme_font_size_override("font_size", 20)
	box.add_child(subtitle)
	select = OptionButton.new()
	select.custom_minimum_size = Vector2(0, 55)
	select.add_item("1  •  BEGINNER — 480", 0)
	select.add_item("2  •  PILOT — 560", 1)
	select.add_item("3  •  EXPERT — 640", 2)
	select.item_selected.connect(_select_difficulty)
	box.add_child(select)
	var start := Button.new()
	start.text = "START GAME"
	start.custom_minimum_size = Vector2(0, 60)
	start.pressed.connect(_start)
	box.add_child(start)
	var instructions := Label.new()
	instructions.text = "SPACE / MOUSE — JUMP\nIN SHIP: HOLD TO FLY UP, RELEASE TO DESCEND\nESC — PAUSED   •   R — RESTART"
	instructions.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	instructions.add_theme_font_size_override("font_size", 17)
	box.add_child(instructions)

func _select_difficulty(index: int) -> void:
	difficulty = index

func _show_menu() -> void:
	state = "menu"
	menu.visible = true
	overlay.visible = false
	hud.visible = false
	bar.visible = false
	held = false

func _start() -> void:
	difficulty = select.selected
	speed = speeds[difficulty]
	speed_mode = 1
	triggered_portals.clear()
	_build_level()
	_reset()
	state = "playing"
	menu.visible = false
	hud.visible = true
	bar.visible = true
	overlay.visible = false

func _build_level() -> void:
	for hazard in timed_hazards:
		hazard.queue_free()
	timed_hazards.clear()
	for block in blocks:
		block.queue_free()
	blocks.clear()
	spikes.clear()
	steps.clear()
	flight_obstacles.clear()
	speed_portals.clear()
	for i in range(5):
		speed_portals.append(Vector2(35500.0 + i * 400.0, i))
	# Three deterministic arrangements with generous recovery zones.
	for section in range(22):
		var base: float = 900.0 + section * 1600.0
		if base > FLIGHT_START - 1200.0 and base < FLIGHT_END + 900.0:
			continue
		var pattern: int = (section * (difficulty + 1) + difficulty) % 5
		if pattern == 0:
			spikes.append(base)
			spikes.append(base + 720.0)
		elif pattern == 1:
			spikes.append(base)
			spikes.append(base + 60.0)
			spikes.append(base + 850.0)
		elif pattern == 2:
			spikes.append(base + 100.0)
			spikes.append(base + 700.0)
			spikes.append(base + 760.0)
		elif pattern == 3:
			steps.append(Vector2(base + 80.0, 58.0))
			steps.append(Vector2(base + 300.0, 116.0))
			steps.append(Vector2(base + 520.0, 174.0))
		else:
			steps.append(Vector2(base + 80.0, 58.0))
			steps.append(Vector2(base + 300.0, 116.0))
			spikes.append(base + 1000.0)
	# Replace isolated single spikes with visible timed hazards. Keep paired
	# spikes and staircase approaches unchanged so timings do not overlap.
	var hazard_kinds: Array[int] = [0, 1, 4, 9, 6, 7, 2, 3, 5, 8]
	var used: int = 0
	for x in spikes.duplicate():
		if used >= hazard_kinds.size(): break
		var isolated := true
		for other in spikes:
			if other != x and absf(other - x) < 350.0: isolated = false
		for step in steps:
			if absf(step.x - x) < 500.0: isolated = false
		if not isolated: continue
		var hazard = HazardScene.instantiate()
		hazard.kind = hazard_kinds[used]
		hazard.position = Vector2(x, GROUND - 175.0 if hazard.kind == 8 else GROUND - 27.0)
		hazard.travel = 25.0 if hazard.kind in [1, 7] else 45.0
		hazard.period = 3.0
		hazard.hit_player.connect(_on_timed_hazard_hit)
		add_child(hazard)
		timed_hazards.append(hazard)
		spikes.erase(x)
		used += 1
	# Alternate top and bottom, then fly through the gap between pairs.
	for i in range(8):
		var x: float = FLIGHT_START + 650.0 + i * 410.0
		var kind: int = (i + difficulty) % 3
		if kind == 0: flight_obstacles.append(Vector2(x, 185))
		elif kind == 1: flight_obstacles.append(Vector2(x, 470))
		else:
			flight_obstacles.append(Vector2(x, 155))
			flight_obstacles.append(Vector2(x, 490))
	for step in steps:
		var block := StaticBody2D.new()
		block.position = Vector2(step.x, GROUND - step.y + 15.0)
		var shape := CollisionShape2D.new()
		var rect := RectangleShape2D.new()
		rect.size = Vector2(124, 30)
		shape.shape = rect
		block.add_child(shape)
		add_child(block)
		blocks.append(block)

func _reset() -> void:
	player.position = Vector2(180, GROUND - SIZE / 2)
	player.velocity = Vector2.ZERO
	time = 0.0
	held = false
	jump_requested = false
	flying = false
	angle = 0.0
	camera.reset_smoothing()
	jump_buffer = 0.0
	coyote_time = 0.0
	queue_redraw()

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and not event.echo:
		if event.keycode == KEY_ESCAPE and event.pressed:
			if state == "playing": state = "paused"; _message("PAUSED\n\nESC — RESUME   •   M — MENU")
			elif state == "paused": state = "playing"; overlay.visible = false
			return
		if event.keycode == KEY_M and event.pressed and state != "playing": _show_menu(); return
		if event.keycode == KEY_R and event.pressed and state != "menu": _start(); return
		if event.keycode == KEY_SPACE:
			_action(event.pressed)
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		_action(event.pressed)
	if event is InputEventScreenTouch:
		_action(event.pressed)

func _action(pressed: bool) -> void:
	if state == "menu": return
	if state == "dead" or state == "won":
		if pressed: _start()
		return
	if state != "playing": return
	held = pressed
	if pressed:
		jump_requested = true
		jump_buffer = PhysicsConfig.JUMP_BUFFER

func _physics_process(delta: float) -> void:
	time += delta
	if state == "playing":
		var was_flying: bool = flying
		flying = player.position.x >= FLIGHT_START and player.position.x < FLIGHT_END
		if flying and not was_flying: player.velocity.y = -260.0
		player.velocity.x = speed
		if flying:
			player.velocity.y += (-PhysicsConfig.SHIP_UP_ACCEL if held else PhysicsConfig.SHIP_DOWN_ACCEL) * delta
			player.velocity.y = clampf(player.velocity.y, -PhysicsConfig.SHIP_MAX_VELOCITY, PhysicsConfig.SHIP_MAX_VELOCITY)
		else:
			player.velocity.y += GRAVITY * delta
			jump_buffer = maxf(0.0, jump_buffer - delta)
			if player.is_on_floor(): coyote_time = PhysicsConfig.COYOTE_TIME
			else: coyote_time = maxf(0.0, coyote_time - delta)
			if (jump_buffer > 0.0 or (held and PhysicsConfig.AUTO_JUMP)) and coyote_time > 0.0:
				player.velocity.y = JUMP
				jump_buffer = 0.0
				coyote_time = 0.0
		jump_requested = false
		var previous_position: Vector2 = player.position
		player.move_and_slide()
		for i in range(speed_portals.size()):
			if not triggered_portals.has(i) and previous_position.x < speed_portals[i].x and player.position.x >= speed_portals[i].x:
				_set_speed_mode(int(speed_portals[i].y))
				triggered_portals[i] = true
		if flying:
			angle = lerp_angle(angle, clampf(player.velocity.y / 800.0, -0.5, 0.5), 0.2)
		elif not player.is_on_floor(): angle += delta * 5.0
		else: angle = lerp_angle(angle, round(angle / (PI / 2.0)) * PI / 2.0, 0.3)
		for x in spikes:
			if minf(previous_position.x, player.position.x) < x + 28.0 and maxf(previous_position.x, player.position.x) > x - 28.0 and maxf(previous_position.y, player.position.y) + SIZE / 2.0 > GROUND - 33.0: _finish(false); break
		if state == "playing":
			for step in steps:
				if minf(previous_position.x, player.position.x) < step.x + 72.0 and maxf(previous_position.x, player.position.x) > step.x - 72.0 and maxf(previous_position.y, player.position.y) + SIZE / 2.0 > GROUND - 20.0: _finish(false); break
		if flying:
			if player.position.y < 90 or player.position.y > GROUND - SIZE / 2 + 1: _finish(false)
			for obstacle in flight_obstacles:
				if minf(previous_position.x, player.position.x) < obstacle.x + 45.0 and maxf(previous_position.x, player.position.x) > obstacle.x - 45.0 and minf(previous_position.y, player.position.y) < obstacle.y + 105.0 and maxf(previous_position.y, player.position.y) > obstacle.y - 105.0: _finish(false)
		if player.position.x >= FINISH: _finish(true)
		_update_hud()
	queue_redraw()

func _on_timed_hazard_hit(body: Node2D) -> void:
	if state == "playing" and body == player:
		_finish(false)

func _set_speed_mode(mode: int) -> void:
	speed_mode = clampi(mode, 0, PhysicsConfig.SPEED_MULTIPLIERS.size() - 1)
	speed = PhysicsConfig.BASE_SPEED * PhysicsConfig.SPEED_MULTIPLIERS[speed_mode]

func _finish(won: bool) -> void:
	if state != "playing": return
	state = "won" if won else "dead"
	best[difficulty] = maxi(best[difficulty], _progress())
	var file := FileAccess.open("user://neon_long_progress.save", FileAccess.WRITE)
	if file:
		for value in best: file.store_32(value)
	_message(("LEVEL COMPLETE!" if won else "CRASHED — %d%%" % _progress()) + "\n\nSPACE / CLICK — RETRY\nM — MENU")

func _load_best() -> void:
	if FileAccess.file_exists("user://neon_long_progress.save"):
		var file := FileAccess.open("user://neon_long_progress.save", FileAccess.READ)
		if file and file.get_length() >= 12:
			for i in range(3): best[i] = clampi(file.get_32(), 0, 100)

func _progress() -> int:
	return clampi(int((player.position.x - 180.0) / (FINISH - 180.0) * 100.0), 0, 100)

func _update_hud() -> void:
	bar.value = _progress()
	hud.text = "%s   %d%%   BEST %d%%   %d u/s" % [names[difficulty], _progress(), best[difficulty], int(speed)]

func _message(text: String) -> void:
	overlay.text = text
	overlay.visible = true

func _draw() -> void:
	if not player: return
	var left: float = player.position.x - 750.0
	draw_rect(Rect2(left, -400, 2400, 1400), Color("0b1028"))
	for i in range(18):
		var x: float = floor(left / 150.0) * 150.0 + i * 150.0
		var h: float = 65.0 + 45.0 * sin(i * 2.3 + time * 0.6)
		draw_rect(Rect2(x, GROUND - h, 85, h), Color(0.10, 0.18, 0.31, 0.75))
		draw_line(Vector2(x, -200), Vector2(x, GROUND), Color(0.18, 0.35, 0.49, 0.12), 1.0)
	for i in range(30):
		var sx: float = left + fposmod(float(i * 239) + time * (15.0 + i % 3 * 5.0), 2300.0)
		var sy: float = 50.0 + fposmod(float(i * 71), 400.0)
		draw_circle(Vector2(sx, sy), 1.5 + (sin(time * 2 + i) + 1.0), Color(0.45, 0.88, 1.0, 0.6))
	draw_rect(Rect2(left, GROUND, 2400, 400), Color("16243b"))
	draw_line(Vector2(left, GROUND), Vector2(left + 2400, GROUND), Color("60f0d9"), 4.0)
	for x in spikes: _draw_spike(x)
	for step in steps:
		for n in range(4): _draw_spike(step.x - 54.0 + n * 36.0, 19.0)
		var block_rect := Rect2(step.x - 62.0, GROUND - step.y, 124.0, 30.0)
		draw_rect(block_rect, Color("344a88"))
		draw_rect(Rect2(block_rect.position, Vector2(124, 6)), Color("b7c8ff"))
	for obstacle in flight_obstacles:
		draw_rect(Rect2(obstacle - Vector2(31, 90), Vector2(62, 180)), Color("ff648e"))
		draw_rect(Rect2(obstacle - Vector2(20, 80), Vector2(40, 160)), Color("a33268"))
	for portal in speed_portals:
		if abs(portal.x - player.position.x) < 1100.0:
			draw_arc(Vector2(portal.x, GROUND - 75), 52, 0, TAU, 32, Color("ffe17d"), 5.0)
			draw_string(ThemeDB.fallback_font, Vector2(portal.x - 30, GROUND - 145), PhysicsConfig.SPEED_NAMES[int(portal.y)], HORIZONTAL_ALIGNMENT_LEFT, -1, 15, Color("ffe17d"))
	for gate in [FLIGHT_START, FLIGHT_END]:
		draw_arc(Vector2(gate, 320), 110, -PI / 2, PI / 2, 40, Color("e1a6ff"), 8)
		draw_arc(Vector2(gate, 320), 110, PI / 2, 3 * PI / 2, 40, Color("e1a6ff"), 8)
	draw_line(Vector2(FINISH, GROUND), Vector2(FINISH, GROUND - 260), Color("ffec90"), 8)
	draw_set_transform(player.position, angle)
	if flying:
		draw_colored_polygon(PackedVector2Array([Vector2(25, 0), Vector2(-22, -15), Vector2(-13, 0), Vector2(-22, 15)]), Color("66f5df"))
		draw_colored_polygon(PackedVector2Array([Vector2(-15, -8), Vector2(-32 - randf() * 8, 0), Vector2(-15, 8)]), Color("ffbd69"))
	else:
		draw_rect(Rect2(-18, -18, 36, 36), Color("66f5df"))
		draw_rect(Rect2(-10, -9, 6, 6), Color("10152d"))
		draw_rect(Rect2(5, -9, 6, 6), Color("10152d"))
	draw_set_transform(Vector2.ZERO)

func _draw_spike(x: float, width: float = 35.0) -> void:
	draw_colored_polygon(PackedVector2Array([Vector2(x - width, GROUND), Vector2(x, GROUND - width * 2), Vector2(x + width, GROUND)]), Color("ff648e"))
