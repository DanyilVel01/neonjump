extends RefCounted
## Movement tuning is expressed in Godot units and seconds.
const PLAYER_SIZE: float = 36.0
const BASE_SPEED: float = 480.0
const GRAVITY: float = 4000.0
const JUMP_IMPULSE: float = 900.0
const JUMP_BUFFER: float = 0.15
const COYOTE_TIME: float = 0.10
const AUTO_JUMP: bool = true
const SPEED_MULTIPLIERS: Array[float] = [0.75, 1.0, 1.25, 1.5, 2.0]
const SPEED_NAMES: Array[String] = ["SLOW", "NORMAL", "FAST", "VERY FAST", "EXTREME"]
const SHIP_UP_ACCEL: float = 1700.0
const SHIP_DOWN_ACCEL: float = 1150.0
const SHIP_MAX_VELOCITY: float = 360.0
static func height() -> float:
    return JUMP_IMPULSE * JUMP_IMPULSE / (2.0 * GRAVITY)
static func airtime() -> float:
    return 2.0 * JUMP_IMPULSE / GRAVITY
static func jump_distance(multiplier: float) -> float:
    return BASE_SPEED * multiplier * airtime()
