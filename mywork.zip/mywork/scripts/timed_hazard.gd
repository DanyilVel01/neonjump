extends Area2D
## Standalone timed hazards. Their phase restarts whenever the scene is instantiated.
signal hit_player(body: Node2D)
@export_enum("Rotating saw", "Moving saw", "Swinging pendulum", "Falling block", "Retractable spikes", "Rotating block", "Crusher", "Flying enemy", "Laser beam", "Rhythm spikes") var kind: int = 0
@export var period: float = 3.0
@export var travel: float = 90.0
var elapsed: float = 0.0
var origin: Vector2
var shape_node: CollisionShape2D
var enabled_now: bool = true

func _ready() -> void:
    origin = position
    collision_layer = 2
    collision_mask = 1
    shape_node = CollisionShape2D.new()
    var shape := RectangleShape2D.new()
    shape.size = Vector2(54, 54)
    if kind == 8: shape.size = Vector2(18, 180)
    shape_node.shape = shape
    add_child(shape_node)
    body_entered.connect(_body_entered)
    queue_redraw()

func _physics_process(delta: float) -> void:
    elapsed += delta
    var cycle: float = fposmod(elapsed, maxf(period, 0.1)) / maxf(period, 0.1)
    var wave: float = sin(cycle * TAU)
    match kind:
        0: rotation += delta * 2.0
        1: position.x = origin.x + travel * wave
        2:
            position.x = origin.x + travel * wave
            position.y = origin.y + travel * 0.25 * (1.0 - cos(cycle * TAU))
        3: position.y = origin.y + travel * clampf((cycle - 0.5) * 4.0, 0.0, 1.0)
        4: position.y = origin.y + travel * (1.0 if cycle > 0.65 else 0.0)
        5: rotation += delta * 1.5
        6: position.y = origin.y + travel * (0.5 - 0.5 * cos(cycle * TAU))
        7:
            position.x = origin.x + travel * wave
            position.y = origin.y + travel * 0.3 * sin(cycle * TAU * 2.0)
        8, 9: enabled_now = cycle >= 0.35 and cycle < 0.75
    shape_node.set_deferred("disabled", not enabled_now)
    queue_redraw()

func _body_entered(body: Node2D) -> void:
    if enabled_now: hit_player.emit(body)

func _draw() -> void:
    var color := Color("ff638d") if enabled_now else Color("6d4264")
    if kind == 8:
        draw_rect(Rect2(-9, -90, 18, 180), color)
    elif kind in [0, 1, 2]:
        draw_circle(Vector2.ZERO, 28, color)
        draw_circle(Vector2.ZERO, 11, Color("22243e"))
        draw_line(Vector2(-25, 0), Vector2(25, 0), Color.WHITE, 3)
    elif kind in [4, 9]:
        draw_colored_polygon(PackedVector2Array([Vector2(-27,27), Vector2(0,-27), Vector2(27,27)]), color)
    else:
        draw_rect(Rect2(-27, -27, 54, 54), color)
        draw_rect(Rect2(-20, -20, 40, 40), Color("4f2453"))
