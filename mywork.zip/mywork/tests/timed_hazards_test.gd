extends SceneTree
var failed: int = 0
func _initialize() -> void: call_deferred("run")
func run() -> void:
    var scene: PackedScene = load("res://scenes/obstacles/timed_hazard.tscn")
    for kind in range(10):
        var hazard = scene.instantiate()
        hazard.kind = kind
        root.add_child(hazard)
        await physics_frame
        if hazard.shape_node == null or hazard.shape_node.shape == null:
            failed += 1
            printerr("FAIL hazard ", kind)
        else: print("PASS hazard ", kind, " has a collision shape")
        hazard.queue_free()
    print("FAILURES: ", failed)
    quit(1 if failed else 0)
