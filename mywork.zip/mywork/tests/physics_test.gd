extends SceneTree
const Config = preload("res://scripts/physics_config.gd")
const Validator = preload("res://scripts/level_validator.gd")
var game
var failures: int = 0
func check(condition: bool, message: String) -> void:
    if not condition:
        failures += 1
        printerr("FAIL: ", message)
    else: print("PASS: ", message)
func _initialize() -> void:
    call_deferred("run_tests")
func run_tests() -> void:
    game = load("res://scenes/game.tscn").instantiate()
    root.add_child(game)
    await process_frame
    check(is_equal_approx(Config.height(), 101.25), "calculated jump height")
    check(is_equal_approx(Config.airtime(), 0.45), "calculated airtime")
    for mode in range(5):
        game.select.select(0)
        game._start()
        game._set_speed_mode(mode)
        check(is_equal_approx(game.speed, Config.BASE_SPEED * Config.SPEED_MULTIPLIERS[mode]), "speed mode %d" % mode)
        # Begin on an empty part of the level and allow the body to settle.
        for n in range(5): await physics_frame
        var start_x: float = game.player.position.x
        var floor_y: float = game.player.position.y
        game._action(true)
        await physics_frame
        game._action(false)
        var minimum_y: float = floor_y
        for n in range(80):
            await physics_frame
            minimum_y = minf(minimum_y, game.player.position.y)
            if n > 10 and game.player.is_on_floor(): break
        var travelled: float = game.player.position.x - start_x
        var measured_height: float = floor_y - minimum_y
        check(measured_height > 90.0 and measured_height < 110.0, "jump height mode %d: %.1f" % [mode, measured_height])
        check(travelled > Config.jump_distance(Config.SPEED_MULTIPLIERS[mode]) * 0.85 and travelled < Config.jump_distance(Config.SPEED_MULTIPLIERS[mode]) * 1.15, "jump range mode %d: %.1f" % [mode, travelled])
    for mode in range(5):
        game._start()
        await physics_frame
        var spike_x: float = game.spikes[0]
        game.player.position = Vector2(spike_x - 80.0, 552.0)
        game.player.velocity = Vector2.ZERO
        game._set_speed_mode(mode)
        for n in range(40):
            await physics_frame
            if game.state == "dead": break
        check(game.state == "dead", "spike collision at speed mode %d" % mode)
    game._start()
    await physics_frame
    game.player.position = Vector2(35495, 552)
    game.player.velocity = Vector2.ZERO
    for n in range(10): await physics_frame
    check(game.triggered_portals.has(0) and game.speed_mode == 0, "speed portal crossing")
    for mode in range(1, 5):
        game.player.position = Vector2(game.speed_portals[mode].x - 5.0, 552.0)
        game.player.velocity = Vector2.ZERO
        for n in range(8): await physics_frame
        check(game.triggered_portals.has(mode) and game.speed_mode == mode and is_equal_approx(game.speed, Config.BASE_SPEED * Config.SPEED_MULTIPLIERS[mode]), "portal sequence mode %d" % mode)
    game._start()
    check(game.triggered_portals.is_empty(), "restart resets portals")
    for difficulty in range(3):
        game.select.select(difficulty)
        game._start()
        check(game.spikes.size() > 0 and game.steps.size() > 0 and game.flight_obstacles.size() > 0, "level %d creates obstacles" % difficulty)
        var warnings: Array[String] = Validator.analyze(game)
        check(warnings.is_empty(), "level %d basic validation: %s" % [difficulty, str(warnings)])
    game._start()
    game.steps.clear()
    game.steps.append(Vector2(1000, 58))
    game.steps.append(Vector2(1220, 400))
    check(not Validator.analyze(game).is_empty(), "validator rejects impossible height")
    game._start()
    game.flight_obstacles.clear()
    game.flight_obstacles.append(Vector2(17000, 250))
    game.flight_obstacles.append(Vector2(17000, 400))
    check(not Validator.analyze(game).is_empty(), "validator rejects blocked ship gap")
    print("FAILURES: ", failures)
    quit(1 if failures else 0)


