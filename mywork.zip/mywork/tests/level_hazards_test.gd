extends SceneTree
func _initialize() -> void: call_deferred("run")
func run() -> void:
    var game = load("res://scenes/game.tscn").instantiate()
    root.add_child(game)
    await process_frame
    for level in range(3):
        game.select.select(level)
        game._start()
        await physics_frame
        print("Level ", level, ": ", game.timed_hazards.size(), " timed hazards")
        assert(game.timed_hazards.size() > 0)
        var obstacle = game.timed_hazards[0]
        game.player.position = obstacle.position - Vector2(70, 0)
        game.player.velocity = Vector2.ZERO
        for i in range(35):
            await physics_frame
            if game.state == "dead": break
        print("Collision state: ", game.state)
        assert(game.state == "dead")
    quit()
