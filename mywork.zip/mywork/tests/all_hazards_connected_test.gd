extends SceneTree
func _initialize() -> void: call_deferred("run")
func run() -> void:
    var game = load("res://scenes/game.tscn").instantiate()
    root.add_child(game)
    await process_frame
    game._start()
    await physics_frame
    for hazard in game.timed_hazards:
        assert(hazard.shape_node != null)
        assert(hazard.hit_player.is_connected(game._on_timed_hazard_hit))
        print("Connected timed hazard kind ", hazard.kind)
    assert(game.timed_hazards.size() == 10)
    quit()
